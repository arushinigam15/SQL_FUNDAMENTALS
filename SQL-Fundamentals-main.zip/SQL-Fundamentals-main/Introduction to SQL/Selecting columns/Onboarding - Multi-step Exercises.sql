-- Onboarding | Multi-step Exercises

SELECT 'SQL is cool'
AS result;