-- Onboarding | Errors
-- If you submit the code to the right, you'll see that you get two types of errors.

-- SQL errors are shown below the editor. These are errors returned by the SQL engine. You should see:

-- syntax error at or near "'DataCamp <3 SQL'" LINE 2: 'DataCamp <3 SQL' ^

select 'DataCamp <3 SQL'
AS result;